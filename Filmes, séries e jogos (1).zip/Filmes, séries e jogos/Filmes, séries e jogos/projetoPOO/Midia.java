package projetoPOO;

public interface Midia {
      public abstract void cadastrarMidias(String T, int A, String C, String S, String I, String P);
}
