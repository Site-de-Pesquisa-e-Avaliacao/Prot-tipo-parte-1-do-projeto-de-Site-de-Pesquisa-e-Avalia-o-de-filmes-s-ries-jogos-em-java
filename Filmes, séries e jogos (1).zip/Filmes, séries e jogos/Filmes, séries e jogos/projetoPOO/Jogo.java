package projetoPOO;

public class Jogo implements Midia {
    private String titulo;
    private int ano;
    private String categoria;
    private String plataforma;
    private String ModoDeJogo;
    private String desenvolvedora;
    private int avaliacao;
    private String resenha;

    private String getTitulo() {
        return titulo;
    }

    private void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    private int getAno() {
        return ano;
    }

    private void setAno(int ano) {
        this.ano = ano;
    }

    private String getCategoria() {
        return categoria;
    }

    private void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    private String getPlataforma() {
        return plataforma;
    }

    private void setPlataforma(String plataforma) {
        this.plataforma = plataforma;
    }

    private String getModoDeJogo() {
        return ModoDeJogo;
    }

    private void setModoDeJogo(String modoDeJogo) {
        ModoDeJogo = modoDeJogo;
    }

    private String getDesenvolvedora() {
        return desenvolvedora;
    }

    private void setDesenvolvedora(String desenvolvedora) {
        this.desenvolvedora = desenvolvedora;
    }

    private int getAvaliacao() {
        return avaliacao;
    }

    private void setAvaliacao(int avaliacao) {
        this.avaliacao = avaliacao;
    }

    private String getResenha() {
        return resenha;
    }

    private void setResenha(String resenha) {
        this.resenha = resenha;
    }

    @Override
    public void cadastrarMidias(String T, int A, String C, String S, String I, String P) {
        setAno(A);
        setTitulo(T);
        setPlataforma(S);
        setCategoria(C);
        setDesenvolvedora(I);
        setModoDeJogo(P);
    }

    public void cadastrarUsuario() {

    }

    public void avaliacaoComentarios() {

    }

    public void listaAvaliacoes() {

    }

    public void listaMidiasPorMedia() {

    }

    public void exibeResenhas() {

    }

    public void filtraMidias() {

    }
}
