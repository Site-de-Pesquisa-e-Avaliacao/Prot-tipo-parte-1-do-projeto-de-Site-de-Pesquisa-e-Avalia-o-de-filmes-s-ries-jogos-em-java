package projetoPOO;

public class Serie implements Midia  {
    private String titulo;
    private int ano;
    private String categoria;
    private String sinopse;
    private String indicacoes;
    private String premios;
    private int avaliacao;
    private String resenha;

    private String getTitulo() {
        return titulo;
    }

    private void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    private int getAno() {
        return ano;
    }

    private void setAno(int ano) {
        this.ano = ano;
    }

    private String getCategoria() {
        return categoria;
    }

    private String getSinopse() {
        return sinopse;
    }

    private void setSinopse(String sinopse) {
        this.sinopse = sinopse;
    }

    private void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    private int getAvaliacao() {
        return avaliacao;
    }

    private void setAvaliacao(int avaliacao) {
        this.avaliacao = avaliacao;
    }

    private String getResenha() {
        return resenha;
    }

    private void setResenha(String resenha) {
        this.resenha = resenha;
    }

    private String getPremios() {
        return premios;
    }

    private void setPremios(String premios) {
        this.premios = premios;
    }

    private String getIndicacoes() {
        return indicacoes;
    }

    private void setIndicacoes(String indicacoes) {
        this.indicacoes = indicacoes;
    }

    @Override
    public void cadastrarMidias(String T, int A, String C, String S, String I, String P) {
        setTitulo(T);
        setAno(A);
        setCategoria(C);
        setSinopse(S);
        setIndicacoes(I);
        setPremios(P);
    }


    public void cadastrarUsuario() {

    }

    public void avaliacaoComentarios() {

    }

    public void listaAvaliacoes() {

    }

    public void listaMidiasPorMedia() {

    }

    public void exibeResenhas() {

    }

    public void filtraMidias() {

    }
}


