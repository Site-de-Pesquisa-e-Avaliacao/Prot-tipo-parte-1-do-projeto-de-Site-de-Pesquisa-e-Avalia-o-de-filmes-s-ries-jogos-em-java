package projetoPOO;

import java.util.ArrayList; 
import java.util.List; 

public class Usuario {
    private String nome;
    private String email;
    private List<Avaliacao> avaliacoesFeitas; //está vermelho porque precisa da classe Avaliação

    private Usuario(String nome, String email) {
        this.nome = nome;
        this.email = email;
        this.avaliacoesFeitas = new ArrayList<>();
    }

    private String getNome() {
        return nome;
    }

    private void setNome(String nome){
        this.nome = nome;
    }

    private String getEmail() {
        return email;
    }

    private void setEmail(String email){
        this.email = email;
    }

    private List<Avaliacao> getAvaliacoesFeitas() {
        return avaliacoesFeitas;
    }

    private void adicionarAvaliacao(Avaliacao avaliacao) {
        this.avaliacoesFeitas.add(avaliacao);
    }
}
