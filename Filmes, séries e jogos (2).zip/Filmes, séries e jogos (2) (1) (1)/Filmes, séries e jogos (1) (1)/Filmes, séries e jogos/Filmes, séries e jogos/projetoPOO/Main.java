package projetoPOO;

public class Main {
    public static void main(String[] args) {
    
        Usuario usuario1 = new Usuario("Ana", "ana@email.com");
        Usuario usuario2 = new Usuario("Beto", "beto@email.com");

        Filme filme1 = new Filme("O Senhor dos Anéis", 2001, "Fantasia", "Um anel de poder...", "Melhor Filme", "Oscar");
        Serie serie1 = new Serie("Stranger Things", 2016, "Ficção Científica", "Um grupo de amigos...", "Nenhuma", "Emmy");
        Jogo jogo1 = new Jogo("The Witcher 3", 2015, "RPG", "PC", "Single Player", "CD Projekt RED");


        Avaliacao avaliacao1 = new Avaliacao(10, "Uma obra-prima! A melhor fantasia de todos os tempos.", usuario1);
        filme1.adicionarAvaliacao(avaliacao1);
        usuario1.adicionarAvaliacao(avaliacao1);

        Avaliacao avaliacao2 = new Avaliacao(9, "Filme incrível, mas achei um pouco longo.", usuario2);
        filme1.adicionarAvaliacao(avaliacao2);
        usuario2.adicionarAvaliacao(avaliacao2);


        Avaliacao avaliacaoRepetida = new Avaliacao(8, "Reassistindo, continua ótimo!", usuario1);
        filme1.adicionarAvaliacao(avaliacaoRepetida);


        Avaliacao avaliacaoSerie = new Avaliacao(8, "Série muito boa, cheia de mistérios.", usuario1);
        serie1.adicionarAvaliacao(avaliacaoSerie);
        usuario1.adicionarAvaliacao(avaliacaoSerie);

        Avaliacao avaliacaoJogo = new Avaliacao(10, "O melhor jogo que já joguei, história e jogabilidade impecáveis.", usuario2);
        jogo1.adicionarAvaliacao(avaliacaoJogo);
        usuario2.adicionarAvaliacao(avaliacaoJogo);

    }
}