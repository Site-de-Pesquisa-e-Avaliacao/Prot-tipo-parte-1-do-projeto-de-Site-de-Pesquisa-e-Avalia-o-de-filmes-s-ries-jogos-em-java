package projetoPOO;

// Criei Armazenamento para armazenar as mídias e colocar aqui a lógica para ordenação delas 

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class Armazenamento {
    private List<Metodos> midias;

    public Armazenamento() {
        this.midias = new ArrayList<>();
    }

    public void adicionarMidia(Metodos midia) {
        this.midias.add(midia);
    }
    
    // em ordem decrescente de nota
    public List<Metodos> listarMidiasPorNotaMedia() {
        this.midias.sort(Comparator.comparing(Metodos::getMediaAvaliacao).reversed());
        return this.midias;
    }
    
    public void exibir() {
        System.out.println(" Mídias ordenadas por nota média ");
        for (Metodos midia : listarMidiasPorNotaMedia()) {
            System.out.println("Título: " + midia.getTitulo() + " | Nota Média: " + String.format("%.2f", midia.getMediaAvaliacao()));
        }
    }


}
