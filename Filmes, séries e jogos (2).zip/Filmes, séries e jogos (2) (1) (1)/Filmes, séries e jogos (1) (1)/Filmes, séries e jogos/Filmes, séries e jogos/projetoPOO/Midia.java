package projetoPOO;

import java.util.List;

public interface Midia {
    String getTitulo();
    void adicionarAvaliacao(Avaliacao avaliacao);
    List<Avaliacao> getAvaliacoes();
}