package projetoPOO;

import java.util.ArrayList;
import java.util.List;

public class Jogo implements Midia {
    private String titulo;
    private int ano;
    private String categoria;
    private String plataforma;
    private String modoDeJogo;
    private String desenvolvedora;
    private List<Avaliacao> avaliacoes;

    public Jogo(String titulo, int ano, String categoria, String plataforma, String modoDeJogo, String desenvolvedora) {
        this.titulo = titulo;
        this.ano = ano;
        this.categoria = categoria;
        this.plataforma = plataforma;
        this.modoDeJogo = modoDeJogo;
        this.desenvolvedora = desenvolvedora;
        this.avaliacoes = new ArrayList<>();
    }

    @Override
    public String getTitulo() {
        return titulo;
    }

    @Override
    public void adicionarAvaliacao(Avaliacao avaliacao) {
        boolean jaAvaliou = false;
        for (Avaliacao a : this.avaliacoes) {
            if (a.getAutor().equals(avaliacao.getAutor())) {
                jaAvaliou = true;
                break;
            }
        }

        if (jaAvaliou) {
            System.out.println("O usuário " + avaliacao.getAutor().getNome() + " já avaliou o jogo " + this.titulo + ".");
        } else {
            this.avaliacoes.add(avaliacao);
            System.out.println("Avaliação adicionada com sucesso ao jogo " + this.titulo + ".");
        }
    }

    @Override
    public List<Avaliacao> getAvaliacoes() {
        return this.avaliacoes;
    }

    public int getAno() {
        return ano;
    }
    public String getCategoria() {
        return categoria;
    }

}